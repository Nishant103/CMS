const express = require ('express');
const Router = express.Router();
const Schema = require('../models/Schema.js')

Router.get("/",(err,res)=>{
    res.render('Login',{title : 'Fill Form', password:'',email:''})
})

Router.post('/Login', async(req,res,next)=>{
    try {
        const {
            Username, 
            email, 
            password,
            cpassword
        } = req.body;

        if (password === cpassword) {

            const userData = new Schema({
                Username, 
                email, 
                password,
            })
            userData.save(err=>{
                if (err) {
                    console.log('err');

                }else{
                    res.render('Login',{title : 'Done', password:'',email:''})
                }
            })

            const useremail = await Schema.findOne({email:email});
                if (email === useremail.email) {

                    res.render('Login',{title : '', password:'',email:'Email is ALready Exist!..'})
                } else {
                    console.log('error');
                }
            
        } else {
            res.render('Login',{title : '', password:'Password not Match',email:''})
        }

    } catch (error) {
        res.render('Login',{title : 'Invalid Data ', password:'',email:''})
    }
})

// sign-in

Router.post('/Login',(req,res,next)=>{
    const {
        email,
        password
    }= req.body;

    Schema.findOne({email:email},(err,result)=>{
        console.log(result);
        if (email === result.email && password === result.password) {
          res.render('dashborad',{name : result.name})
        } else {
            console.log('err');
        }
    })
})


Router.get("/",);





module.exports = Router;